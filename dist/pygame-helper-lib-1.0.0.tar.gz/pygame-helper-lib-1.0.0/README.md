# Pygame Helper
A helper library for pygame made by [@VL07](https://github.com/VL07)

## Installation
To install this library simply download it and put the folder in your projects main folder, and import it into your code

## Features
* Base game object with error handling
* Debuger like F3 in Minecraft
* Scene system

## Planned features
* Animation loader
* Image font loader/system
* Save load system
* Base objects
* Particles
* Gui system
* Animation system 
